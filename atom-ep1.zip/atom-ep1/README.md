# atom-ep1 — Paradoks Sentuhan Atom (Remotion + three.js)
```
npm install
npm run still     # cek frame 1440 (pivot deep night blue) -> out/still.png
npm run studio    # preview
npm run render    # 1440x2560, out/atom_ep1.mp4 (suara sudah di dalam komposisi)
```
Catatan: render 2K sekitar 4 fps. Di Codespaces beri disk/RAM cukup; Chromium dipasang Remotion otomatis saat pertama kali render.
Timing kata masih perkiraan: ganti `T` di src/story.ts setelah ada words.json. Detail: SCRIPT.md.
