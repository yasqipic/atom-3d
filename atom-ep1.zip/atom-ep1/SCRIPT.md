# Paradoks Sentuhan Atom — SCRIPT.md
Audio final: atom_ep1.mp3 = 85.47 s → 30 fps → **2565 frame** (ceil 2564.1). Vertikal 1080x1920 (final 1440x2560, --scale 1.3333).
Bahasa: Indonesia. Tanpa caption/label. Tanpa maskot tambahan: hanya manusia bean-head (outline plum) + objek dunia 3D.
Timing di bawah = PERKIRAAN dari user. Ganti dengan words.json (hand-fix) lalu edit `T` di story.ts.

## Fakta & sumber (periksa sebelum publish)
- Atom hampir seluruhnya ruang kosong: inti ~1/100.000 diameter atom, jadi volume terisi jauh di bawah 0,0001 %. Naskah menulis "99,9 %": benar tapi sangat konservatif (sebenarnya >99,9999 %). Sumber: Britannica "atom"; Lawrence Berkeley Lab "ABC of atoms".
- "Triliunan atom": tubuh manusia ~7×10^27 atom (kuadriliun-kuadriliun). Frasa "triliunan" meremehkan; pertimbangkan "septiliunan".
- Penolakan antar-elektron (Coulomb) + prinsip larangan Pauli yang membuat benda padat tak bisa saling menembus. Sumber: Feynman Lectures Vol. III; HyperPhysics "Pauli exclusion".
- "Melayang di atas kursi": jarak kontak ~ skala nanometer/angstrom (≈10^-10 m), bukan "sepersekian miliar meter" harfiah di tiap sentuhan; ini penyederhanaan populer.
- Sensasi sentuhan: mekanoreseptor kulit yang mendeteksi deformasi kulit akibat gaya kontak elektromagnetik, bukan "tekanan medan" langsung. Naskah menyederhanakan.
(Naskah dipakai persis seperti dikirim; catatan di atas hanya peringatan akurasi.)

## Naskah (anchor perkiraan)
| Waktu | Kalimat |
|---|---|
| 0:00–0:08 | Secara fisika, kamu belum pernah benar-benar menyentuh kursi yang sedang kamu duduki... karena sekarang pun tubuhmu sedang melayang di atasnya. |
| 0:08–0:16 | Setiap benda di sekitar kita, termasuk tanganmu dan kursi itu, tersusun dari triliunan atom yang sembilan puluh sembilan koma sembilan persen isinya hanyalah ruang kosong. |
| 0:16–0:22 | Saat kamu mencoba menempelkan jari ke permukaan meja, kamu mengira kulit dan kayu itu bertabrakan secara fisik. |
| 0:22–0:31 | Padahal, jauh sebelum kedua inti atom itu sempat bersentuhan, awan elektron di bagian terluar atom tanganmu dan atom meja sudah berhadapan lebih dulu. |
| 0:31–0:38 | Semakin keras kamu menekan meja, semakin kuat pula medan listrik tak kasat mata di antara keduanya saling mendorong balik. |
| 0:38–0:48 | Untungnya, gaya tolak inilah yang membuat tubuhmu tidak langsung ambles menembus lantai menuju inti Bumi. Sialnya, gaya yang sama juga membuatmu mustahil menyentuh orang yang kamu sayang secara harfiah. |
| **0:48** | **PIVOT: "Jadi gini..." → deep night blue** prinsipnya persis seperti dua magnet dengan kutub yang sama saat kamu paksa didekatkan. |
| 0:55–1:00 | Kedua magnet itu terasa seperti saling menabrak benda padat, padahal di tengahnya ada celah kosong yang tak pernah menyatu. |
| 1:00–1:07 | Sinyal saraf yang otakmu terjemahkan sebagai rasa sentuhan sebenarnya hanyalah tekanan dari medan elektromagnetik tersebut. |
| 1:07–1:25 | Jadi, selama hidupmu, setiap pelukan, jabat tangan, dan langkah kakimu hanyalah ilusi melayang pada jarak sepersekian miliar meter. + hold akhir, fade out. |

Catatan: kalimat terakhir hanya ~5 s bicara tetapi diberi jendela 18 s. Setelah words.json ada, atur `VOICE_END` di story.ts; sisanya jadi hold akhir.

## Cast (milik sendiri, bukan maskot)
- **Raka** (dewasa, 3.5 head-heights, jaket kuning-mustard): "kamu". Satu-satunya tokoh utama.
- **Sinta** (dewasa, syal terakota): "orang yang kamu sayang", muncul 0:43–1:25.
- Tanpa hewan/robot/atom-berwajah. Atom, elektron, medan = objek 3D bercat + kartu efek 2D (panah, percikan, garis medan).

## Shot plan (30 fps; frame = detik×30)
| id | frame | isi | cahaya | DOF cInf px@1080 |
|---|---|---|---|---|
| s01 | 0–120 | Hook: kamar kerja siang, Raka duduk di kursi, kamera rendah, celah tipis garis terang antara pantat & dudukan | warmDay | 15 |
| s02 | 120–240 | Insert celah kursi, "melayang" ditunjukkan dengan sandal ikut terangkat tipis, partikel debu | warmDay | 16 |
| s03 | 240–360 | Dive makro ke telapak tangan → permukaan kulit jadi lanskap atom | warmDay | 12 |
| s04 | 360–480 | Atom: inti kecil (kelereng) di stadion kosong; awan elektron tipis | warmDay | 0 (wide, tajam) |
| s05 | 480–570 | Jari mendekat ke meja kayu, CU | warmDay | 13 |
| s06 | 570–660 | Kulit & serat kayu "bertabrakan?" (tanda tanya efek kartu, bukan teks) | warmDay | 12 |
| s07 | 660–780 | Makro: dua awan elektron bertemu, inti jauh di belakang | warmDay | 12 |
| s08 | 780–930 | Samping lebar: dua inti berjarak jauh, awan menyentuh duluan ("padahal") | warmDay | 0 |
| s09 | 930–1030 | Jari menekan lebih keras, urat tangan tegang, meja tidak bergerak | warmDay | 13 |
| s10 | 1030–1140 | Panah/garis medan listrik mendorong balik; KICK | warmDay | 10 |
| s11 | 1140–1305 | "Untungnya": Raka berdiri aman di lantai, potongan penampang: lantai→tanah→inti Bumi tak tertembus | warmDay | 0 |
| s12 | 1305–1437 | "Sialnya": Raka ulur tangan ke Sinta, percikan menolak, celah tipis | warmDay | 10 |
| — | 1437–1445 | XFADE 8 f warmDay→night (reaksi 3 f sebelum "Jadi") | blend | — |
| s13 | 1437–1560 | "Jadi gini": dua magnet di meja, lampu meja hangat sebagai pool, ruangan deep night blue | night | 11 |
| s14 | 1560–1650 | Magnet didekatkan, kutub sama menolak, CU | night | 13 |
| s15 | 1650–1800 | Celah kosong di antara magnet dibuka dengan berkas cahaya | night | 12 |
| s16 | 1800–2010 | Sinyal saraf (kartu pulsa) merambat jari→lengan→kepala | night | 10 |
| s17 | 2010–2190 | Pelukan Raka & Sinta, garis celah bercahaya di dada | night | 11 |
| s18 | 2190–2310 | Jabat tangan CU, celah antara telapak | night | 13 |
| s19 | 2310–2430 | Langkah kaki: telapak sepatu melayang di atas lantai | night | 12 |
| s20 | 2430–2565 | Hold akhir wide: dua siluet di jendela malam, creeping push-in, fade out 15 f terakhir | night | 0 |

Aturan bawaan skill: setiap hold creep push-in 0,15–0,35 %/f (0,6 %/f di kata tekanan), tak ada hold statis ≥4 f, kick flip-shake meluruh 7 f, roll 4–5°, reaksi visual 0–3 f sebelum kata, ink #030303 5.1→3.3 px (1080), kartu karakter di layer NOINK.
