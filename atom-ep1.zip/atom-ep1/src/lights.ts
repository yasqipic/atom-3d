// lights.ts — atom_ep1. Sun camera-relative, frozen per shot (skill rule).
export type LightId = 'warmDay' | 'night';

export interface LightPreset {
  az: number; el: number;            // derajat, relatif kamera
  lit: [number, number, number];     // warna sisi terang (HDR)
  shade: [number, number, number];   // warna sisi bayangan (biru/ungu, tidak pernah cokelat)
  lift: [number, number, number];    // tint dingin HANYA di bayangan
  uSat: number;
  fog: { near: number; far: number };
  pool?: { color: string; intensity: number; radius: number }; // light pool (lampu meja/jendela)
}

export const LIGHTS: Record<LightId, LightPreset> = {
  // Siang hangat: dasar preset "day" skill, key digeser ke krem-emas, shade tetap biru.
  warmDay: {
    az: 70, el: 52,
    lit: [1.62, 1.48, 1.22],
    shade: [0.30, 0.29, 0.38],
    lift: [0.05, 0.06, 0.11],
    uSat: 1.10,
    fog: { near: 25, far: 300 },
  },
  // Deep night blue: moonlight dingin dari jendela + satu pool lampu meja hangat.
  // Shade tetap biru-nila (facade ≈ #1c2250), tanpa hitam pekat (p5 non-ink ≥ ~.12).
  night: {
    az: 215, el: 28,
    lit: [0.46, 0.60, 1.05],
    shade: [0.09, 0.11, 0.26],
    lift: [0.03, 0.05, 0.16],
    uSat: 1.08,
    fog: { near: 18, far: 220 },
    pool: { color: '#ffb36b', intensity: 1.6, radius: 2.6 },
  },
};

export interface LookPalette {
  skyTop: string; skyHorizon: string; fog: string; cloud: string; sunDisc?: string;
  stars?: boolean; window?: string;
}

// fog = warna horizon (aturan skill).
export const LOOK: Record<LightId, LookPalette> = {
  warmDay: { skyTop: '#4a86d6', skyHorizon: '#cfdcec', fog: '#cfdcec', cloud: '#fff4e2', sunDisc: '#fff1c9' },
  night:   { skyTop: '#050c2e', skyHorizon: '#243a86', fog: '#243a86', cloud: '#34478f', stars: true, window: '#1d2f78' },
};

export const lightAt = (f: number, xfadeAt: number): LightId => (f >= xfadeAt ? 'night' : 'warmDay');
