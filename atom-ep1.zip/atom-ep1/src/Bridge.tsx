// Bridge.tsx — komposisi Remotion "AtomShort" (nama file mengikuti skill). three.js + post: DOF → bloom → tone map NEUTRAL, MSAA 4.
// Ink = inverted hull di build.ts (pengganti ink.ts); DOF = postprocessing DepthOfField (pengganti lensblur.ts).
import React, { useMemo } from 'react';
import { AbsoluteFill, Audio, staticFile, useCurrentFrame } from 'remotion';
import { ThreeCanvas } from '@remotion/three';
import { useThree } from '@react-three/fiber';
import { EffectComposer, DepthOfField, Bloom, ToneMapping } from '@react-three/postprocessing';
import { ToneMappingMode } from 'postprocessing';
import * as THREE from 'three';
import { TOTAL, FPS, XFADE, FLASH_AT, FADE_OUT, shotAt } from './story';
import { SKY, applyFrame } from './world';
import { buildWorld } from './build';
import { buildCast } from './cast';

const W = 1080, H = 1920;

const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const { camera, size } = useThree();
  const world = useMemo(() => buildWorld(), []);
  const cast = useMemo(() => buildCast(), []);
  const cam = camera as THREE.PerspectiveCamera;
  const info = applyFrame(frame, cam, size.width, size.height);
  world.anim(frame); cast.update(frame, cam);
  const px = size.height / 1920; // semua parameter piksel skala dengan tinggi output / 1920
  return (
    <>
      <primitive object={SKY} />
      <primitive object={world.root} />
      <primitive object={cast.root} />
      <EffectComposer multisampling={4}>
        <DepthOfField worldFocusDistance={info.focus} worldFocusRange={Math.max(0.6, info.focus * 0.35)} bokehScale={info.dof * 0.55 * px} />
        <Bloom luminanceThreshold={1.0} intensity={0.5} mipmapBlur radius={0.6} levels={6} />
        <ToneMapping mode={ToneMappingMode.NEUTRAL} />
      </EffectComposer>
    </>
  );
};

// Dip 8 f di tiap pergantian tempat/waktu (pendekatan crossfade); puncaknya tepat di batas shot.
const dip = (f: number) => {
  let o = 0;
  for (const x of XFADE) { const t = (f - (x.at - x.dur / 2)) / x.dur; if (t > 0 && t < 1) o = Math.max(o, Math.sin(Math.PI * t) * 0.75); }
  return o;
};
const flash = (f: number) => { for (const a of FLASH_AT) { const d = f - a; if (d >= 0 && d < 4) return [1, 0.7, 0.4, 0.15][d]; } return 0; };

export const AtomShort: React.FC = () => {
  const f = useCurrentFrame();
  const night = shotAt(f).light === 'night';
  const fade = f >= FADE_OUT.from ? (f - FADE_OUT.from) / (FADE_OUT.to - FADE_OUT.from) : 0;
  return (
    <AbsoluteFill style={{ background: '#000' }}>
      <ThreeCanvas width={W} height={H} camera={{ fov: 40, near: 0.05, far: 600, position: [0, 1, 3] }} gl={{ antialias: false }}>
        <Scene />
      </ThreeCanvas>
      <AbsoluteFill style={{ background: night ? '#0a1440' : '#fff1d8', opacity: dip(f), pointerEvents: 'none' }} />
      <AbsoluteFill style={{ background: '#fff', opacity: flash(f), pointerEvents: 'none' }} />
      <AbsoluteFill style={{ background: '#000', opacity: fade, pointerEvents: 'none' }} />
      <Audio src={staticFile('atom_ep1.mp3')} />
    </AbsoluteFill>
  );
};
export const ATOM_META = { id: 'AtomShort', width: W, height: H, fps: FPS, durationInFrames: TOTAL };
