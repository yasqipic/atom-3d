// world.ts — atom_ep1. Kamera per frame, cahaya (warmDay→night), sky shader, uniform bersama.
import * as THREE from 'three';
import { LIGHTS, LOOK } from './lights';
import { SHOTS, XFADE, CAMS, shotAt, kickOffset, dofAt } from './story';
import type { CamPose } from './story';

const D = Math.PI / 180;
export const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const smoother = (t: number) => { t = clamp(t); return t * t * t * (t * (t * 6 - 15) + 10); };
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

export const PIVOT_F = SHOTS.find(s => s.light === 'night')!.a;          // 1437
export const PIVOT_DUR = XFADE.find(x => x.at === PIVOT_F)!.dur;         // 8
export const nightMix = (f: number) => smoother((f - PIVOT_F) / PIVOT_DUR);

// Celah magnet (m): lebar → menyempit di s14 → tetap sempit (s15+). Dipakai build.ts & cast.ts.
export const magnetGap = (f: number) => {
  if (f < 1560) return lerp(0.5, 0.42, smoother((f - PIVOT_F) / 123));
  if (f < 1650) return lerp(0.42, 0.07, smoother((f - 1560) / 80));
  return 0.07 + 0.004 * Math.sin(f * 0.25);
};

// ---- Kamera ----
const lerp3 = (a: number[], b: number[], t: number) => a.map((v, i) => lerp(v, b[i], t)) as [number, number, number];
const keyAt = (id: string, f: number) => { const ks = CAMS[id]; let k = ks[0]; for (const x of ks) if (x.f <= f) k = x; return k; };
export function camAt(f: number): CamPose {
  const shot = shotAt(f), key = keyAt(shot.id, f);
  let p = key.s(f - key.f);
  if (!key.cut && key.dur && f - key.f < key.dur && shot.a > 0) {
    const ps = shotAt(shot.a - 1), pk = keyAt(ps.id, shot.a - 1);
    const q = pk.s(shot.a - 1 - pk.f), t = smoother((f - key.f) / key.dur);
    p = { pos: lerp3(q.pos, p.pos, t), look: lerp3(q.look, p.look, t), fov: lerp(q.fov, p.fov, t), roll: lerp(q.roll, p.roll, t) };
  }
  return p;
}

// ---- Uniform bersama ----
const col = (h: string) => new THREE.Color(h);
export const UNI = {
  uLit: { value: new THREE.Color() }, uShade: { value: new THREE.Color() }, uLift: { value: new THREE.Color() },
  uSunDir: { value: new THREE.Vector3(0.5, 0.8, 0.3) },
  uFogCol: { value: new THREE.Color() }, uFogNear: { value: 25 }, uFogFar: { value: 300 }, uSat: { value: 1.1 },
  uPoolCol: { value: col('#ffb36b') }, uPoolPos: { value: new THREE.Vector3(0.9, 1.15, -0.15) },
  uPoolI: { value: 0 }, uPoolR: { value: 2.6 },
};
export const INK = { uRes: { value: new THREE.Vector2(1080, 1920) }, uScale: { value: 1 } };

// ---- Sky ----
export const SKY = new THREE.Mesh(
  new THREE.SphereGeometry(450, 32, 16),
  new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, fog: false,
    uniforms: { uTop: { value: new THREE.Color() }, uHor: { value: new THREE.Color() }, uStars: { value: 0 } },
    vertexShader: 'varying vec3 vD; void main(){ vD=normalize(position); gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.); }',
    fragmentShader: `uniform vec3 uTop,uHor; uniform float uStars; varying vec3 vD;
      float h(vec3 p){ return fract(sin(dot(p,vec3(12.9898,78.233,37.719)))*43758.5453); }
      void main(){ float t=smoothstep(0.0,0.75,vD.y); vec3 c=mix(uHor,uTop,t);
        vec3 g=floor(vD*220.); float s=step(0.9985,h(g))*smoothstep(0.15,0.5,vD.y)*uStars; c+=vec3(s)*1.6;
        gl_FragColor=vec4(c,1.); }`,
  }),
);
SKY.frustumCulled = false; SKY.renderOrder = -10;

// ---- Matahari/bulan relatif kamera, beku per shot ----
const sunCache = new Map<string, THREE.Vector3>();
function sunFor(shotId: string, shotA: number, which: 'warmDay' | 'night') {
  const key = shotId + which; let v = sunCache.get(key);
  if (!v) {
    const p = camAt(shotA), fx = p.look[0] - p.pos[0], fz = p.look[2] - p.pos[2];
    const th = Math.atan2(fx, fz), L = LIGHTS[which], phi = th + L.az * D, el = L.el * D;
    v = new THREE.Vector3(Math.sin(phi) * Math.cos(el), Math.sin(el), Math.cos(phi) * Math.cos(el));
    sunCache.set(key, v);
  }
  return v;
}

const A = LIGHTS.warmDay, B = LIGHTS.night, LA = LOOK.warmDay, LB = LOOK.night;
const mixCol = (out: THREE.Color, a: THREE.Color | number[], b: THREE.Color | number[], t: number) => {
  const x = Array.isArray(a) ? a : [a.r, a.g, a.b], y = Array.isArray(b) ? b : [b.r, b.g, b.b];
  out.setRGB(lerp(x[0], y[0], t), lerp(x[1], y[1], t), lerp(x[2], y[2], t));
};

export interface FrameInfo { dof: number; focus: number; }
export function applyFrame(f: number, cam: THREE.PerspectiveCamera, w: number, h: number): FrameInfo {
  const pose = camAt(f), shot = shotAt(f), m = nightMix(f);
  cam.fov = pose.fov; cam.aspect = w / h;
  cam.position.set(...pose.pos); cam.up.set(0, 1, 0); cam.lookAt(...pose.look); cam.rotateZ(pose.roll);
  const kick = kickOffset(f) * (w / 1080);
  if (kick) cam.setViewOffset(w, h, 0, kick, w, h); else cam.clearViewOffset();
  cam.updateProjectionMatrix();

  mixCol(UNI.uLit.value, A.lit, B.lit, m); mixCol(UNI.uShade.value, A.shade, B.shade, m); mixCol(UNI.uLift.value, A.lift, B.lift, m);
  mixCol(UNI.uFogCol.value, col(LA.fog), col(LB.fog), m);
  UNI.uFogNear.value = lerp(A.fog.near, B.fog.near, m); UNI.uFogFar.value = lerp(A.fog.far, B.fog.far, m);
  UNI.uSat.value = lerp(A.uSat, B.uSat, m);
  UNI.uSunDir.value.copy(sunFor(shot.id, shot.a, 'warmDay')).lerp(sunFor(shot.id, shot.a, 'night'), m).normalize();
  UNI.uPoolI.value = B.pool!.intensity * m; UNI.uPoolR.value = B.pool!.radius;

  const u = (SKY.material as THREE.ShaderMaterial).uniforms;
  mixCol(u.uTop.value, col(LA.skyTop), col(LB.skyTop), m); mixCol(u.uHor.value, col(LA.skyHorizon), col(LB.skyHorizon), m);
  u.uStars.value = m; SKY.position.copy(cam.position);

  INK.uRes.value.set(w, h); INK.uScale.value = h / 1920;
  const focus = new THREE.Vector3(...pose.pos).distanceTo(new THREE.Vector3(...pose.look));
  return { dof: dofAt(f), focus };
}
