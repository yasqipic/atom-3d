// story.ts — "Paradoks Sentuhan Atom" (atom_ep1). 30 fps, 2565 frame (85.47 s), 1080x1920.
// Semua waktu dalam detik di T = PERKIRAAN; ganti dengan words.json lalu hand-fix.
import type { LightId } from './lights';

export const FPS = 30;
export const AUDIO_SEC = 85.47;
export const TOTAL = Math.ceil(AUDIO_SEC * FPS); // 2565
export const S = (sec: number) => Math.round(sec * FPS);

// Anchor kata kunci (detik). Reaksi visual mendarat 0–3 f SEBELUM kata (lihat LEAD).
export const T = {
  hook: 0, melayang: 6.2, kosong: 12.5, jari: 16, padahal: 22, keras: 31,
  untungnya: 38, sialnya: 43.5, pivot: 48, magnet: 49.5, celah: 55, saraf: 60,
  pelukan: 67, voiceEnd: 73, // voiceEnd: tebakan; hold akhir dari sini
} as const;
export const LEAD = 3; // frame

export type CrowdMode = 'none' | 'raka' | 'duo';
export interface Shot { id: string; a: number; b: number; light: LightId; crowd: CrowdMode; tau: number; }

// a inklusif, b eksklusif; tau = progres waktu cerita 0..1
const sh = (id: string, a: number, b: number, light: LightId, crowd: CrowdMode, tau: number): Shot =>
  ({ id, a, b, light, crowd, tau });
const PIVOT = S(T.pivot) - LEAD; // 1437

export const SHOTS: Shot[] = [
  sh('s01', 0, 120, 'warmDay', 'raka', 0.00),
  sh('s02', 120, 240, 'warmDay', 'raka', 0.02),
  sh('s03', 240, 360, 'warmDay', 'none', 0.05),
  sh('s04', 360, 480, 'warmDay', 'none', 0.08),
  sh('s05', 480, 570, 'warmDay', 'raka', 0.12),
  sh('s06', 570, 660, 'warmDay', 'raka', 0.14),
  sh('s07', 660, 780, 'warmDay', 'none', 0.18),
  sh('s08', 780, 930, 'warmDay', 'none', 0.22),
  sh('s09', 930, 1030, 'warmDay', 'raka', 0.28),
  sh('s10', 1030, 1140, 'warmDay', 'raka', 0.32),
  sh('s11', 1140, 1305, 'warmDay', 'raka', 0.38),
  sh('s12', 1305, PIVOT, 'warmDay', 'duo', 0.45),
  sh('s13', PIVOT, 1560, 'night', 'raka', 0.56),
  sh('s14', 1560, 1650, 'night', 'none', 0.62),
  sh('s15', 1650, 1800, 'night', 'none', 0.68),
  sh('s16', 1800, 2010, 'night', 'raka', 0.74),
  sh('s17', 2010, 2190, 'night', 'duo', 0.82),
  sh('s18', 2190, 2310, 'night', 'duo', 0.88),
  sh('s19', 2310, 2430, 'night', 'raka', 0.94),
  sh('s20', 2430, TOTAL, 'night', 'duo', 1.00),
];

// Pergantian tempat/waktu: crossfade 8 f (aturan skill 6–8 f). Fade ke night mulai 3 f sebelum "Jadi".
export const XFADE: { at: number; dur: number }[] = [
  { at: 240, dur: 8 },   // dive ke makro
  { at: 360, dur: 8 },   // masuk dunia atom
  { at: 480, dur: 8 },   // kembali ke meja
  { at: PIVOT, dur: 8 }, // warmDay → deep night blue (selesai f1445; titik tengah ≈ detik 48.0)
  { at: 2430, dur: 8 },
];
export const FLASH_AT: number[] = [S(4.0)]; // flash putih 4 f setelah hook "melayang"

// ---- Kamera ----
export type Vec3 = [number, number, number];
export interface CamPose { pos: Vec3; look: Vec3; fov: number; roll: number; }
export interface CamKey { f: number; dur?: number; cut?: boolean; s: (local: number) => CamPose; }

// Creeping push-in: rate = fraksi jarak ke target per frame (0.0015–0.0035; 0.006 untuk kata tekanan).
const push = (pos: Vec3, look: Vec3, fov: number, rate: number, roll = 0) => (lf: number): CamPose => {
  const k = Math.min(rate * lf, 0.6);
  return { pos: [pos[0] + (look[0] - pos[0]) * k, pos[1] + (look[1] - pos[1]) * k, pos[2] + (look[2] - pos[2]) * k], look, fov, roll };
};
// Orbit pelan + push, untuk wide.
const sway = (pos: Vec3, look: Vec3, fov: number, rate: number, arc: number, roll = 0) => (lf: number): CamPose => {
  const k = Math.min(rate * lf, 0.6), a = arc * lf;
  const dx = pos[0] - look[0], dz = pos[2] - look[2];
  const x = look[0] + dx * Math.cos(a) - dz * Math.sin(a), z = look[2] + dx * Math.sin(a) + dz * Math.cos(a);
  return { pos: [x + (look[0] - x) * k, pos[1] + (look[1] - pos[1]) * k, z + (look[2] - z) * k], look, fov, roll };
};
const D = Math.PI / 180;
const deg = (n: number) => n * D;

// Koordinat: meter; kamar kerja di origin, meja di (0,0.75,0), Raka di (−0.6,0,0.4). Atom: skala bebas di (40,0,0).
// Pose awal mengikuti tata letak build.ts; sesuaikan setelah tata letak dunia final. Roll ±4–4.6° pada beat dramatis.
export const CAMS: Record<string, CamKey[]> = {
  s01: [{ f: 0, cut: true, s: push([1.6, 0.35, 2.4], [-0.6, 0.55, 0.4], 38, 0.0028, deg(-4)) }],
  s02: [{ f: 120, cut: true, s: push([-0.1, 0.38, 1.1], [-0.6, 0.42, 0.4], 34, 0.0035, deg(4.2)) }],
  s03: [{ f: 240, cut: true, s: push([-0.3, 1.0, 0.9], [-0.55, 0.85, 0.45], 30, 0.006, deg(-4)) }],
  s04: [{ f: 360, cut: true, s: sway([46, 2.5, 22], [40, 1.2, 0], 52, 0.0018, deg(0.05)) }],
  s05: [{ f: 480, cut: true, s: push([0.5, 1.0, 1.0], [0.05, 0.78, 0.2], 32, 0.0028, deg(4.4)) }],
  s06: [{ f: 570, s: push([0.25, 0.9, 0.55], [0.0, 0.76, 0.1], 28, 0.0035, deg(-4.4)), dur: 22 }],
  s07: [{ f: 660, cut: true, s: push([40.0, 1.0, 5.2], [40.0, 1.0, 0], 30, 0.0030, deg(4)) }],
  s08: [{ f: 780, dur: 24, s: sway([44, 1.2, 9], [40, 1.0, 0], 50, 0.0016, deg(0.05)) }],
  s09: [{ f: 930, cut: true, s: push([0.55, 0.95, 0.7], [0.05, 0.78, 0.15], 30, 0.006, deg(-4.6)) }],
  s10: [{ f: 1030, dur: 18, s: push([0.35, 0.95, 0.5], [0.05, 0.8, 0.1], 28, 0.0040, deg(4.6)) }],
  s11: [{ f: 1140, cut: true, s: sway([4.5, 1.6, 6.0], [0, 0.4, 0], 46, 0.0016, deg(0.03)) }],
  s12: [{ f: 1305, dur: 24, s: push([0.6, 1.2, 3.0], [0.0, 1.1, 0.4], 36, 0.0030, deg(-4.2)) }],
  s13: [{ f: PIVOT, cut: true, s: push([-1.1, 1.35, 1.9], [0.0, 0.85, 0.0], 38, 0.0026, deg(4)) }],
  s14: [{ f: 1560, dur: 20, s: push([0.5, 0.95, 0.6], [0.0, 0.8, 0.0], 28, 0.0040, deg(-4.4)) }],
  s15: [{ f: 1650, dur: 24, s: push([0.15, 0.84, 0.35], [0.0, 0.8, 0.0], 26, 0.0034, deg(4.2)) }],
  s16: [{ f: 1800, cut: true, s: push([0.8, 1.25, 1.6], [0.0, 1.15, 0.3], 34, 0.0024, deg(-4)) }],
  s17: [{ f: 2010, cut: true, s: push([2.2, 1.35, 3.0], [0.0, 1.2, 0.0], 40, 0.0022, deg(4.2)) }],
  s18: [{ f: 2190, dur: 20, s: push([0.7, 1.15, 0.9], [0.0, 1.1, 0.0], 28, 0.0034, deg(-4.4)) }],
  s19: [{ f: 2310, cut: true, s: push([0.9, 0.22, 1.4], [0.0, 0.08, 0.0], 32, 0.0030, deg(4.6)) }],
  s20: [{ f: 2430, dur: 30, s: sway([0.0, 1.6, 7.5], [0.0, 1.2, 0.0], 44, 0.0015, deg(0.03)) }],
};

// Impact flip-shake: ganti tanda tiap frame, meluruh 7 f.
export const KICKS: { f: number; amp: number }[] = [
  { f: S(T.kosong) - LEAD, amp: 5 },   // "kosong"
  { f: S(T.padahal) - LEAD, amp: 6 },  // "Padahal"
  { f: S(T.keras) - LEAD, amp: 9 },    // "keras"
  { f: 1075, amp: 11 },                // tolak balik terkuat
  { f: S(T.sialnya) - LEAD, amp: 8 },  // "Sialnya"
  { f: S(T.celah) - LEAD, amp: 7 },    // "celah kosong"
];
export const kickOffset = (f: number): number => {
  let o = 0;
  for (const k of KICKS) { const d = f - k.f; if (d >= 0 && d < 7) o += (d % 2 ? -1 : 1) * k.amp * (1 - d / 7); }
  return o; // px @1080
};

// Lens blur cInf (px @1080) per shot. Fokus di mata/jari depan. Wide = 0.
export const DOF: Record<string, number> = {
  s01: 15, s02: 16, s03: 12, s04: 0, s05: 13, s06: 12, s07: 12, s08: 0, s09: 13, s10: 10,
  s11: 0, s12: 10, s13: 11, s14: 13, s15: 12, s16: 10, s17: 11, s18: 13, s19: 12, s20: 0,
};
export const shotAt = (f: number): Shot => SHOTS.find(s => f >= s.a && f < s.b) ?? SHOTS[SHOTS.length - 1];
export const dofAt = (f: number): number => DOF[shotAt(f).id] ?? 0;

// Prop framing dekat (~1/3 shot). Pastikan dikenali, tidak terpotong jadi blob (≥2 m dari lensa).
export const FOREGROUND: Record<string, string> = {
  s01: 'tanaman-pot-kiri', s05: 'cangkir-kopi', s09: 'pensil-di-meja',
  s13: 'lampu-meja-bokeh', s17: 'tirai-jendela-malam', s19: 'sandal-rumah',
};

// Fade out akhir 15 f ke hitam.
export const FADE_OUT = { from: TOTAL - 15, to: TOTAL };
// Daftar kata → reaksi (isi ulang dari words.json): [kata, detikMulai, shot, efek]
export const REACTIONS: [string, number, string, string][] = [
  ['melayang', T.melayang, 's02', 'celah-kursi+debu'],
  ['kosong', T.kosong, 's04', 'stadion-kosong'],
  ['Padahal', T.padahal, 's08', 'awan-menyentuh-duluan'],
  ['keras', T.keras, 's10', 'panah-medan+KICK'],
  ['Untungnya', T.untungnya, 's11', 'lantai-menahan'],
  ['Sialnya', T.sialnya, 's12', 'percikan-tolak'],
  ['Jadi gini', T.pivot, 's13', 'deep-night-blue'],
  ['celah', T.celah, 's15', 'berkas-cahaya+KICK'],
  ['saraf', T.saraf, 's16', 'pulsa-saraf'],
];
