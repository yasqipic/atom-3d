// cast.ts — Raka & Sinta: kartu 2D bean-head (outline plum) sebagai billboard di dunia 3D, + kartu efek.
// Kartu bukan mesh ber-ink dunia (tidak punya hull) → otomatis "NOINK". Tanpa maskot.
import * as THREE from 'three';
import { shotAt } from './story';
import type { Vec3 } from './story';
import { LIGHTS } from './lights';
import { nightMix, magnetGap } from './world';

const K = 0.00185, CW = 600, CH = 1000, INKC = '#241726';
type Face = 'neutral' | 'smile' | 'worry' | 'surprise' | 'sad';
type Pt = [number, number];
interface Pose { hl: Pt; hr: Pt; fl: Pt; fr: Pt; drop: number; kneeOut?: number; tip?: Pt }
const FEET = { fl: [268, 975] as Pt, fr: [332, 975] as Pt };
export const POSES: Record<string, Pose> = {
  stand: { hl: [222, 585], hr: [378, 585], ...FEET, drop: 0 },
  sit: { hl: [240, 640], hr: [420, 520], fl: [262, 975], fr: [338, 975], drop: 170, kneeOut: 46 },
  press: { hl: [222, 585], hr: [455, 560], ...FEET, drop: 0, tip: [485, 572] },
  reach: { hl: [222, 585], hr: [500, 390], ...FEET, drop: 0, tip: [525, 388] },
  step: { hl: [222, 585], hr: [378, 585], fl: [270, 948], fr: [335, 948], drop: 0 },
  hugA: { hl: [392, 470], hr: [392, 430], ...FEET, drop: 0 },
  hugB: { hl: [208, 430], hr: [208, 470], ...FEET, drop: 0 },
  shakeA: { hl: [160, 590], hr: [435, 560], ...FEET, drop: 0 },
  shakeB: { hl: [165, 560], hr: [440, 590], ...FEET, drop: 0 },
};

type Who = 'raka' | 'sinta';
const STYLE: Record<Who, { skin: string; top: string; hair: string; extra: string }> = {
  raka: { skin: '#e8b98e', top: '#d9a030', hair: '#2b1b14', extra: '' },
  sinta: { skin: '#c98f66', top: '#5b8f8a', hair: '#1f1414', extra: '#c8553d' },
};

function bean(c: CanvasRenderingContext2D, cx: number, cy: number) {
  const hw = 142, hh = 134; c.beginPath();
  c.moveTo(cx, cy - hh - 8);
  c.bezierCurveTo(cx + hw * 0.95, cy - hh * 0.9, cx + hw * 1.05, cy + hh * 0.4, cx + hw * 0.45, cy + hh);
  c.quadraticCurveTo(cx, cy + hh * 1.12, cx - hw * 0.45, cy + hh);
  c.bezierCurveTo(cx - hw * 1.05, cy + hh * 0.4, cx - hw * 0.95, cy - hh * 0.9, cx, cy - hh - 8); c.closePath();
}
const limb = (c: CanvasRenderingContext2D, a: Pt, mid: Pt, b: Pt) => {
  c.strokeStyle = INKC; c.lineWidth = 16; c.lineCap = 'round'; c.lineJoin = 'round';
  c.beginPath(); c.moveTo(...a); c.quadraticCurveTo(mid[0], mid[1], ...b); c.stroke();
};
function face(c: CanvasRenderingContext2D, cx: number, cy: number, f: Face, blink: boolean) {
  c.fillStyle = INKC; c.strokeStyle = INKC; c.lineWidth = 8; c.lineCap = 'round';
  for (const s of [-1, 1]) {
    const x = cx + s * 37, y = cy + 8;
    if (blink) { c.beginPath(); c.moveTo(x - 12, y); c.lineTo(x + 12, y); c.stroke(); }
    else { c.beginPath(); c.arc(x, y, f === 'surprise' ? 12 : 9, 0, 7); c.fill(); }
    if (f === 'worry' || f === 'sad') { c.beginPath(); c.moveTo(x - 14 * s, y - 30 - 6 * s * -1); c.lineTo(x + 14 * s, y - 40 + 0); c.stroke(); }
    if (f === 'surprise') { c.beginPath(); c.moveTo(x - 14, y - 32); c.lineTo(x + 14, y - 32); c.stroke(); }
  }
  c.beginPath();
  if (f === 'smile') c.arc(cx, cy + 50, 26, 0.2, Math.PI - 0.2);
  else if (f === 'surprise') c.ellipse(cx, cy + 66, 12, 17, 0, 0, 7);
  else if (f === 'worry') { c.moveTo(cx - 20, cy + 68); c.quadraticCurveTo(cx - 8, cy + 58, cx, cy + 68); c.quadraticCurveTo(cx + 8, cy + 78, cx + 20, cy + 66); }
  else if (f === 'sad') c.arc(cx, cy + 84, 22, Math.PI + 0.3, -0.3);
  else { c.moveTo(cx - 16, cy + 66); c.lineTo(cx + 16, cy + 66); }
  c.stroke();
}
function figure(c: CanvasRenderingContext2D, who: Who, p: Pose, f: Face, blink: boolean, cx: number) {
  const S = STYLE[who], d = p.drop, cy = 150 + d; c.save(); c.translate(cx - 300, 0);
  // kaki (stick) + sepatu
  for (const [hx, ft, s] of [[275, p.fl, -1], [325, p.fr, 1]] as [number, Pt, number][]) {
    const hip: Pt = [hx, 600 + d], knee: Pt = p.kneeOut ? [hx + s * p.kneeOut, (hip[1] + ft[1]) / 2 + 20] : [(hx + ft[0]) / 2, (hip[1] + ft[1]) / 2];
    limb(c, hip, knee, ft); c.fillStyle = INKC; c.beginPath(); c.ellipse(ft[0] + s * 8, ft[1] + 4, 26, 12, 0, 0, 7); c.fill();
  }
  // badan
  c.fillStyle = S.top; c.strokeStyle = INKC; c.lineWidth = 9; c.beginPath();
  c.moveTo(240, 300 + d); c.lineTo(360, 300 + d); c.lineTo(348, 610 + d); c.lineTo(252, 610 + d); c.closePath(); c.fill(); c.stroke();
  // lengan + tangan titik tinta
  for (const [sx, h, s] of [[250, p.hl, -1], [350, p.hr, 1]] as [number, Pt, number][]) {
    const sh: Pt = [sx, 330 + d], mid: Pt = [(sh[0] + h[0]) / 2, (sh[1] + h[1]) / 2 + 36];
    limb(c, sh, mid, h); c.fillStyle = INKC; c.beginPath(); c.arc(h[0] + s * 2, h[1], 12, 0, 7); c.fill();
  }
  if (who === 'sinta') { c.fillStyle = '#1f1414'; c.beginPath(); c.ellipse(300, cy + 30, 160, 175, 0, 0, 7); c.fill(); c.stroke(); }
  if (who === 'sinta') { c.fillStyle = S.extra; c.strokeStyle = INKC; c.fillRect(250, 285 + d, 100, 30); c.strokeRect(250, 285 + d, 100, 30); }
  bean(c, 300, cy); c.fillStyle = S.skin; c.fill(); c.strokeStyle = INKC; c.lineWidth = 10; c.stroke();
  // rambut
  c.save(); bean(c, 300, cy); c.clip(); c.fillStyle = S.hair;
  c.beginPath(); c.moveTo(150, cy - 200); c.lineTo(450, cy - 200); c.lineTo(450, cy - 55); c.quadraticCurveTo(375, cy - 100, 300, cy - 70); c.quadraticCurveTo(225, cy - 105, 150, cy - 55); c.closePath(); c.fill(); c.restore();
  if (who === 'sinta') { c.fillStyle = S.hair; c.strokeStyle = INKC; c.lineWidth = 8; c.beginPath(); c.arc(300, cy - 160, 40, 0, 7); c.fill(); c.stroke(); }
  bean(c, 300, cy); c.strokeStyle = INKC; c.lineWidth = 10; c.stroke();
  face(c, 300, cy, f, blink); c.restore();
}
function drawCard(kind: string, who: Who, pose: string, f: Face, blink: boolean, mirror: boolean) {
  const cv = document.createElement('canvas'); cv.width = CW; cv.height = CH; const c = cv.getContext('2d')!;
  if (mirror) { c.translate(CW, 0); c.scale(-1, 1); }
  if (kind === 'hug') { figure(c, 'raka', POSES.hugA, f, blink, 255); figure(c, 'sinta', POSES.hugB, f, blink, 345); }
  else if (kind === 'shake') { figure(c, 'raka', POSES.shakeA, f, blink, 150); figure(c, 'sinta', POSES.shakeB, f, blink, 450); }
  else figure(c, who, POSES[pose], f, blink, 300);
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t;
}

// ---- Pemeran per shot ----
interface Entry { kind?: 'hug' | 'shake'; who: Who; pose: string; x: number; z: number; tip?: Vec3; mirror?: boolean; tipDesign?: Pt }
const R = (pose: string, x: number, z: number, tip?: Vec3): Entry => ({ who: 'raka', pose, x, z, tip });
const PRESS: Vec3 = [0.05, 0.78, 0.2];
export const CAST: Record<string, Entry[]> = {
  s01: [R('sit', -0.6, 0.4)], s02: [R('sit', -0.6, 0.4)], s03: [R('sit', -0.6, 0.4)],
  s05: [R('press', -0.5, 0.9, PRESS)], s06: [R('press', -0.5, 0.9, PRESS)],
  s09: [R('press', -0.5, 0.9, PRESS)], s10: [R('press', -0.5, 0.9, PRESS)],
  s11: [R('stand', 0, 0.5)],
  s12: [R('reach', -0.9, 0.4, [-0.03, 1.1, 0.4]), { who: 'sinta', pose: 'reach', x: 0.9, z: 0.4, tip: [0.03, 1.1, 0.4], mirror: true }],
  s13: [R('sit', -0.6, 0.4)],
  s16: [R('reach', -0.3, 0.3, [0.1, 1.15, 0.3])],
  s17: [{ kind: 'hug', who: 'raka', pose: 'hugA', x: 0, z: 0, tipDesign: [300, 450] }],
  s18: [{ kind: 'shake', who: 'raka', pose: 'shakeA', x: 0, z: 0, tip: [0, 1.0, 0], tipDesign: [300, 560] }],
  s19: [R('step', 0, 0)],
  s20: [R('stand', -0.45, 1.5), { who: 'sinta', pose: 'stand', x: 0.45, z: 1.5 }],
};
const FACE: Record<string, Face> = {
  s01: 'neutral', s02: 'surprise', s03: 'worry', s05: 'neutral', s06: 'worry', s09: 'worry', s10: 'surprise', s11: 'smile',
  s12: 'sad', s13: 'neutral', s16: 'surprise', s17: 'smile', s18: 'smile', s19: 'neutral', s20: 'neutral',
};

// Kedip deterministik: tiap 15–69 f, lama 4 f.
const blinkStarts: number[] = []; { let t = 12, s = 7; while (t < 2700) { blinkStarts.push(t); s = (s * 1103515245 + 12345) & 0x7fffffff; t += 15 + (s % 55); } }
const blinking = (f: number, off: number) => blinkStarts.some(b => f >= b + off && f < b + off + 4);

// ---- Efek (kartu 2D datar; tanpa teks/label) ----
type FxKind = 'spark' | 'arrow' | 'glow' | 'gap';
interface Fx { shots: string[]; kind: FxKind; at: any; size: [number, number]; rot?: number; period?: number }
const FX: Fx[] = [
  { shots: ['s02'], kind: 'spark', at: { type: 'card', i: 0, u: 300, v: 775 }, size: [0.16, 0.16], period: 30 },
  { shots: ['s06'], kind: 'spark', at: { type: 'tip', i: 0, o: [0, 0.02, 0.02] }, size: [0.18, 0.18], period: 24 },
  { shots: ['s08'], kind: 'spark', at: { type: 'world', p: [40, 1, 0] }, size: [1.0, 1.0], period: 36 },
  { shots: ['s08'], kind: 'glow', at: { type: 'world', p: [40, 1, 0.05] }, size: [1.8, 1.8], period: 36 },
  ...[-0.07, 0, 0.07].map((dx): Fx => ({ shots: ['s10'], kind: 'arrow', at: { type: 'tip', i: 0, o: [dx, 0.1, 0.02] }, size: [0.12, 0.07], rot: Math.PI / 2, period: 18 })),
  { shots: ['s12'], kind: 'spark', at: { type: 'world', p: [0, 1.1, 0.42] }, size: [0.22, 0.22], period: 20 },
  { shots: ['s12'], kind: 'gap', at: { type: 'world', p: [0, 1.1, 0.4] }, size: [0.05, 0.22], period: 30 },
  { shots: ['s14'], kind: 'arrow', at: { type: 'magnet', side: -1 }, size: [0.16, 0.09], rot: Math.PI, period: 14 },
  { shots: ['s14'], kind: 'arrow', at: { type: 'magnet', side: 1 }, size: [0.16, 0.09], rot: 0, period: 14 },
  { shots: ['s15'], kind: 'gap', at: { type: 'world', p: [0, 0.82, 0.06] }, size: [0.1, 0.25], period: 40 },
  ...[0, 1, 2, 3, 4].map((n): Fx => ({ shots: ['s16'], kind: 'glow', at: { type: 'path', i: 0, from: [525, 388], to: [300, 120], n, of: 5 }, size: [0.1, 0.1], period: 45 })),
  { shots: ['s17'], kind: 'gap', at: { type: 'card', i: 0, u: 300, v: 450 }, size: [0.03, 0.55], period: 50 },
  { shots: ['s18'], kind: 'gap', at: { type: 'card', i: 0, u: 300, v: 560 }, size: [0.05, 0.12], period: 40 },
  { shots: ['s19'], kind: 'gap', at: { type: 'card', i: 0, u: 335, v: 962 }, size: [0.22, 0.03], period: 40 },
];
function fxTex(kind: FxKind) {
  const cv = document.createElement('canvas'); cv.width = cv.height = 256; const c = cv.getContext('2d')!;
  c.lineJoin = 'round'; c.strokeStyle = INKC; c.lineWidth = 10;
  if (kind === 'spark') { c.fillStyle = '#ffd34a'; c.beginPath(); for (let i = 0; i < 16; i++) { const a = i * Math.PI / 8, r = i % 2 ? 40 : 118; c.lineTo(128 + Math.cos(a) * r, 128 + Math.sin(a) * r); } c.closePath(); c.fill(); c.stroke(); }
  else if (kind === 'arrow') { c.fillStyle = '#ff7a3a'; c.beginPath(); c.moveTo(20, 96); c.lineTo(150, 96); c.lineTo(150, 50); c.lineTo(240, 128); c.lineTo(150, 206); c.lineTo(150, 160); c.lineTo(20, 160); c.closePath(); c.fill(); c.stroke(); }
  else { const g = c.createRadialGradient(128, 128, 0, 128, 128, 128); g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.35, 'rgba(255,240,190,.7)'); g.addColorStop(1, 'rgba(255,230,160,0)'); c.fillStyle = g; c.fillRect(0, 0, 256, 256); }
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; return t;
}

export function buildCast() {
  const root = new THREE.Group();
  const blank = new THREE.Texture();
  const cards = [0, 1].map(() => {
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(CW * K, CH * K), new THREE.MeshBasicMaterial({ map: blank, transparent: true, alphaTest: 0.5, side: THREE.DoubleSide, fog: false }));
    const sc = document.createElement('canvas'); sc.width = sc.height = 64; const x = sc.getContext('2d')!;
    const g = x.createRadialGradient(32, 32, 0, 32, 32, 32); g.addColorStop(0, 'rgba(10,6,20,.9)'); g.addColorStop(1, 'rgba(10,6,20,0)'); x.fillStyle = g; x.fillRect(0, 0, 64, 64);
    const sh = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.4), new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(sc), transparent: true, depthWrite: false, opacity: 0.5, polygonOffset: true, polygonOffsetFactor: -2 }));
    sh.rotation.x = -Math.PI / 2; root.add(mesh, sh); return { mesh, sh };
  });
  const texCache = new Map<string, THREE.Texture>(); const fxT = { spark: fxTex('spark'), arrow: fxTex('arrow'), glow: fxTex('glow'), gap: fxTex('gap') };
  const fxMeshes = FX.map(fx => {
    const add = fx.kind === 'glow' || fx.kind === 'gap';
    const mat = new THREE.MeshBasicMaterial({ map: fxT[fx.kind], transparent: true, depthWrite: false, fog: false, blending: add ? THREE.AdditiveBlending : THREE.NormalBlending });
    if (add) { mat.color.setScalar(1.8); mat.toneMapped = false; }
    const m = new THREE.Mesh(new THREE.PlaneGeometry(fx.size[0], fx.size[1]), mat); m.visible = false; root.add(m); return m;
  });
  const last: { centre: THREE.Vector3; right: THREE.Vector3; mirror: boolean }[] = [];
  const toWorld = (i: number, u: number, v: number) => { const L = last[i]; const uu = (L.mirror ? CW - u : u); return L.centre.clone().addScaledVector(L.right, (uu - 300) * K).addScaledVector(new THREE.Vector3(0, 1, 0), (500 - v) * K); };

  return {
    root,
    update(f: number, cam: THREE.Camera) {
      const shot = shotAt(f), list = CAST[shot.id] ?? [], m = nightMix(f);
      const L = LIGHTS.warmDay.lit.map((v, i) => v * (1 - m) + LIGHTS.night.lit[i] * m), S = LIGHTS.warmDay.shade.map((v, i) => v * (1 - m) + LIGHTS.night.shade[i] * m);
      const tint = L.map((v, i) => Math.min(1, v * 0.55 + S[i] * 0.45 + 0.12)); // lit oleh cahaya scene, tanpa emissive
      cards.forEach((c, i) => {
        const e = list[i]; c.mesh.visible = c.sh.visible = !!e; if (!e) return;
        const fc = FACE[shot.id] ?? 'neutral', bl = blinking(f, i * 11), mir = !!e.mirror;
        const key = `${e.kind ?? ''}|${e.who}|${e.pose}|${fc}|${bl}|${mir}`; let t = texCache.get(key);
        if (!t) { t = drawCard(e.kind ?? '', e.who, e.pose, fc, bl, mir); texCache.set(key, t); }
        const mat = c.mesh.material as THREE.MeshBasicMaterial; mat.map = t; mat.color.setRGB(tint[0], tint[1], tint[2]);
        const tipD = e.tipDesign ?? (e.kind ? undefined : POSES[e.pose].tip);
        const base = new THREE.Vector3(e.x, 0, e.z); const tipW = e.tip ? new THREE.Vector3(...e.tip) : null;
        const ref = tipW ?? base; const ry = Math.atan2(cam.position.x - ref.x, cam.position.z - ref.z);
        const right = new THREE.Vector3(Math.cos(ry), 0, -Math.sin(ry)); const centre = new THREE.Vector3();
        if (tipW && tipD) { const tx = mir ? CW - tipD[0] : tipD[0]; centre.copy(tipW).addScaledVector(right, -(tx - 300) * K).y -= (500 - tipD[1]) * K; }
        else centre.set(e.x, 475 * K, e.z);
        const lean = tipW ? 0 : Math.sin(f * 0.04 + i) * 2 * Math.PI / 180;
        c.mesh.position.copy(centre); c.mesh.rotation.set(0, ry, lean, 'YXZ');
        c.sh.position.set(centre.x, 0.006, centre.z); (c.sh.material as THREE.MeshBasicMaterial).opacity = 0.5 * (1 - 0.4 * m);
        last[i] = { centre, right, mirror: mir };
      });
      FX.forEach((fx, k) => {
        const mesh = fxMeshes[k], on = fx.shots.includes(shot.id) && last[0] !== undefined; mesh.visible = on; if (!on) return;
        const t = (f - shot.a), per = fx.period ?? 30, ph = (t % per) / per, a = fx.at; let p = new THREE.Vector3();
        if (a.type === 'world') p.set(...(a.p as Vec3));
        else if (a.type === 'card') p = toWorld(a.i, a.u, a.v);
        else if (a.type === 'tip') { const e = list[a.i]; p.set(...(e.tip as Vec3)).add(new THREE.Vector3(...(a.o as Vec3))); }
        else if (a.type === 'magnet') { p.set(a.side * (magnetGap(f) / 2 + 0.36), 0.82, 0.0); }
        else if (a.type === 'path') { const q = ((t * 0.025) + a.n / a.of) % 1; p = toWorld(a.i, a.from[0] + (a.to[0] - a.from[0]) * q, a.from[1] + (a.to[1] - a.from[1]) * q); }
        mesh.position.copy(p); mesh.quaternion.copy(cam.quaternion); if (fx.rot) mesh.rotateZ(fx.rot);
        const pulse = 0.75 + 0.35 * Math.sin(ph * Math.PI * 2); mesh.scale.setScalar(fx.kind === 'arrow' ? 0.9 + 0.2 * Math.sin(ph * Math.PI * 2) : pulse);
        mesh.position.z += 0.001;
      });
    },
  };
}
