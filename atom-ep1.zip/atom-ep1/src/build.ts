// build.ts — dunia 3D atom_ep1: kamar kerja, dunia atom, magnet, penampang Bumi.
// Semua mesh pakai two-tone shader + ink hull (inverted hull, lebar piksel konstan 5.1→3.3 px @1080).
import * as THREE from 'three';
import { mergeVertices } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { UNI, INK, magnetGap, nightMix, PIVOT_F } from './world';

const VERT = `varying vec3 vN; varying vec3 vW; varying vec2 vUv; varying float vDepth;
void main(){ vec4 w=modelMatrix*vec4(position,1.); vW=w.xyz; vN=normalize(mat3(modelMatrix)*normal); vUv=uv;
  vec4 mv=viewMatrix*w; vDepth=-mv.z; gl_Position=projectionMatrix*mv; }`;
const FRAG = `uniform vec3 uColor; uniform sampler2D uMap; uniform float uHasMap;
uniform vec3 uLit,uShade,uLift,uSunDir,uFogCol,uPoolCol,uPoolPos; uniform float uFogNear,uFogFar,uSat,uPoolI,uPoolR;
varying vec3 vN; varying vec3 vW; varying vec2 vUv; varying float vDepth;
void main(){ vec3 base=uColor; if(uHasMap>0.5) base*=texture2D(uMap,vUv).rgb;
  vec3 n=normalize(vN); if(!gl_FrontFacing) n=-n;
  float lit=smoothstep(-0.02,0.04,dot(n,normalize(uSunDir)));
  vec3 c=base*mix(uShade+uLift,uLit,lit);
  float pd=distance(vW,uPoolPos); float pool=uPoolI*smoothstep(uPoolR,0.0,pd)*(0.4+0.6*max(dot(n,normalize(uPoolPos-vW)),0.0));
  c+=base*uPoolCol*pool;
  float l=dot(c,vec3(0.2126,0.7152,0.0722)); c=mix(vec3(l),c,uSat);
  c=mix(c,uFogCol,smoothstep(uFogNear,uFogFar,vDepth));
  gl_FragColor=vec4(c,1.0); }`;

export function toonMat(color: string | number, map?: THREE.Texture | null) {
  return new THREE.ShaderMaterial({
    vertexShader: VERT, fragmentShader: FRAG,
    uniforms: { ...UNI, uColor: { value: new THREE.Color(color) }, uMap: { value: map ?? null }, uHasMap: { value: map ? 1 : 0 } },
  });
}
export const glowMat = (color: string, k = 2.2, opacity = 1) => {
  const m = new THREE.MeshBasicMaterial({ color: new THREE.Color(color).multiplyScalar(k), transparent: opacity < 1, opacity, fog: false });
  m.toneMapped = false; return m;
};

const inkMat = new THREE.ShaderMaterial({
  side: THREE.BackSide,
  uniforms: { uRes: INK.uRes, uScale: INK.uScale },
  vertexShader: `uniform vec2 uRes; uniform float uScale;
    void main(){ vec4 mv=modelViewMatrix*vec4(position,1.); vec4 cp=projectionMatrix*mv;
      vec3 nv=normalize(normalMatrix*normal); vec2 d=(projectionMatrix*vec4(nv,0.)).xy; float L=length(d); d=L>1e-5?d/L:vec2(0.);
      float px=mix(5.1,3.3,smoothstep(6.0,90.0,-mv.z))*uScale;
      cp.xy+=d*(px*2.0/uRes)*cp.w; gl_Position=cp; }`,
  fragmentShader: 'void main(){ gl_FragColor=vec4(0.012,0.012,0.012,1.0); }',
});
function hullGeo(g: THREE.BufferGeometry) {
  const c = g.clone(); c.deleteAttribute('normal'); c.deleteAttribute('uv');
  const m = mergeVertices(c, 1e-4); m.computeVertexNormals(); return m;
}
export function solid(geo: THREE.BufferGeometry, color: string | number, o: { map?: THREE.Texture; ink?: boolean } = {}) {
  const g = new THREE.Group(); g.add(new THREE.Mesh(geo, toonMat(color, o.map)));
  if (o.ink !== false) g.add(new THREE.Mesh(hullGeo(geo), inkMat));
  return g;
}
const box = (w: number, h: number, d: number, c: string, p: [number, number, number], o: { map?: THREE.Texture; ink?: boolean } = {}) => {
  const s = solid(new THREE.BoxGeometry(w, h, d), c, o); s.position.set(...p); return s;
};
const cyl = (rt: number, rb: number, h: number, c: string, p: [number, number, number], seg = 20) => {
  const s = solid(new THREE.CylinderGeometry(rt, rb, h, seg), c); s.position.set(...p); return s;
};
const ball = (r: number, c: string, p: [number, number, number]) => {
  const s = solid(new THREE.SphereGeometry(r, 20, 14), c); s.position.set(...p); return s;
};

function canvasTex(w: number, h: number, draw: (c: CanvasRenderingContext2D) => void, repeat?: [number, number]) {
  const cv = document.createElement('canvas'); cv.width = w; cv.height = h; draw(cv.getContext('2d')!);
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(...repeat); }
  return t;
}
const planks = (base: string[], seam: string, n = 8) => canvasTex(512, 512, c => {
  const w = 512 / n;
  for (let i = 0; i < n; i++) { c.fillStyle = base[i % base.length]; c.fillRect(i * w, 0, w, 512); c.fillStyle = seam; c.fillRect(i * w, 0, 4, 512); }
  for (let i = 0; i < 40; i++) { c.fillStyle = 'rgba(60,30,10,.10)'; c.fillRect(Math.random() * 512 | 0, Math.random() * 512 | 0, 40, 2); }
}, [2, 2]);

export const LAMP: [number, number, number] = [0.9, 1.15, -0.15];

export function buildWorld() {
  const root = new THREE.Group();
  const wood = planks(['#c58a50', '#b97f46', '#cf9558'], '#3a2414');
  const floorTex = planks(['#c9955c', '#bb8650', '#d29c62'], '#33200f', 10); floorTex.repeat.set(3, 3);

  // --- Kamar ---
  root.add(box(7, 0.1, 6.5, '#ffffff', [0, -0.05, 0], { map: floorTex }));
  // Penampang Bumi di bawah lantai (s11): tanah → batuan → magma → inti.
  root.add(box(7, 1.1, 6.5, '#7a5a3e', [0, -0.65, 0]));
  root.add(box(7, 1.3, 6.5, '#6f6a78', [0, -1.85, 0]));
  root.add(box(7, 1.6, 6.5, '#e0662e', [0, -3.3, 0]));
  const core = new THREE.Mesh(new THREE.SphereGeometry(0.9, 24, 16), glowMat('#ffd25a', 2.0)); core.position.set(0, -3.4, 3.2); root.add(core);
  root.add(box(7, 3.2, 0.15, '#e6d3b0', [0, 1.6, -2.6]));
  root.add(box(0.15, 3.2, 5.2, '#dcc7a2', [-3.5, 1.6, 0]));
  root.add(box(0.15, 3.2, 5.2, '#dcc7a2', [3.5, 1.6, 0]));
  root.add(box(7, 0.12, 0.1, '#8a5a3a', [0, 0.06, -2.5], { ink: false })); // plint
  // Jendela
  const pane = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 1.2), new THREE.MeshBasicMaterial({ color: '#cfe6ff', fog: false }));
  pane.position.set(1.4, 1.7, -2.5); root.add(pane);
  for (const [w, h, x, y] of [[1.72, 0.07, 1.4, 2.33], [1.72, 0.07, 1.4, 1.07], [0.07, 1.2, 0.57, 1.7], [0.07, 1.2, 2.23, 1.7], [0.04, 1.2, 1.4, 1.7]] as number[][])
    root.add(box(w, h, 0.08, '#f1e9da', [x, y, -2.47]));
  // Tirai
  root.add(box(0.35, 1.6, 0.1, '#b9553a', [0.42, 1.7, -2.4])); root.add(box(0.35, 1.6, 0.1, '#b9553a', [2.38, 1.7, -2.4]));
  // Meja (permukaan y=0.75)
  root.add(box(1.6, 0.06, 0.9, '#ffffff', [0.35, 0.72, 0.05], { map: wood }));
  for (const [x, z] of [[-0.4, -0.35], [1.1, -0.35], [-0.4, 0.45], [1.1, 0.45]]) root.add(box(0.06, 0.69, 0.06, '#8a5a3a', [x, 0.345, z]));
  // Kursi (dudukan y=0.36)
  root.add(box(0.5, 0.06, 0.5, '#4d6a8a', [-0.6, 0.33, 0.4]));
  root.add(box(0.5, 0.55, 0.06, '#4d6a8a', [-0.6, 0.66, 0.13]));
  for (const [x, z] of [[-0.82, 0.18], [-0.38, 0.18], [-0.82, 0.62], [-0.38, 0.62]]) root.add(box(0.04, 0.3, 0.04, '#2f3e52', [x, 0.15, z]));
  // Props
  root.add(cyl(0.045, 0.04, 0.1, '#f4efe4', [0.8, 0.8, 0.3]));
  const handle = solid(new THREE.TorusGeometry(0.03, 0.009, 8, 14), '#f4efe4'); handle.position.set(0.85, 0.8, 0.3); root.add(handle);
  const pencil = solid(new THREE.CylinderGeometry(0.008, 0.008, 0.18, 8), '#e8b830'); pencil.position.set(0.3, 0.765, 0.3); pencil.rotation.z = Math.PI / 2; pencil.rotation.y = 0.4; root.add(pencil);
  root.add(cyl(0.16, 0.12, 0.3, '#b9553a', [1.9, 0.15, 1.0]));
  for (const [x, y, z, r] of [[1.9, 0.5, 1.0, 0.2], [1.78, 0.62, 1.05, 0.16], [2.02, 0.64, 0.95, 0.16], [1.9, 0.78, 1.0, 0.14]] as number[][]) root.add(ball(r, '#4f8a4a', [x, y, z]));
  // Lampu meja
  root.add(cyl(0.1, 0.12, 0.03, '#2d3b4a', [LAMP[0], 0.765, LAMP[2] - 0.0]));
  root.add(cyl(0.012, 0.012, 0.4, '#2d3b4a', [LAMP[0], 0.96, LAMP[2]]));
  const shade = solid(new THREE.ConeGeometry(0.13, 0.14, 20, 1, true), '#d9a030'); shade.position.set(LAMP[0], 1.17, LAMP[2]); shade.rotation.x = Math.PI; root.add(shade);
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.04, 12, 10), glowMat('#ffd9a0', 3.0)); bulb.position.set(LAMP[0], 1.12, LAMP[2]); root.add(bulb);
  // Sandal
  root.add(box(0.12, 0.04, 0.28, '#d98a5a', [0.5, 0.02, 0.75])); root.add(box(0.12, 0.04, 0.28, '#d98a5a', [0.68, 0.02, 0.78]));

  // --- Magnet (muncul sejak pivot) ---
  const mkMag = (facingRight: boolean) => {
    const g = new THREE.Group();
    const a = box(0.16, 0.07, 0.1, '#3b6fd9', [-0.08, 0, 0]), b = box(0.16, 0.07, 0.1, '#d9453b', [0.08, 0, 0]);
    g.add(a, b); if (!facingRight) g.rotation.y = Math.PI; return g;
  };
  const magL = mkMag(true), magR = mkMag(false); // kutub merah sama-sama menghadap celah
  magL.position.y = magR.position.y = 0.785; root.add(magL, magR);
  const beam = new THREE.Mesh(new THREE.BoxGeometry(1, 0.2, 0.1), glowMat('#cfe0ff', 1.6, 0.5)); beam.position.set(0, 0.8, 0); root.add(beam);

  // --- Dunia atom di x=40 (stadion kosong) ---
  const atoms = new THREE.Group(); atoms.position.set(40, 1, 0); root.add(atoms);
  const pitchTex = canvasTex(1024, 1024, c => {
    for (let i = 16; i > 0; i--) { c.fillStyle = i % 2 ? '#9ccf7a' : '#8cc06c'; c.beginPath(); c.arc(512, 512, i * 32, 0, 7); c.fill(); }
    c.strokeStyle = '#f4f1e6'; c.lineWidth = 6; c.beginPath(); c.arc(512, 512, 140, 0, 7); c.stroke();
  });
  const pitch = new THREE.Mesh(new THREE.CircleGeometry(40, 64), toonMat('#ffffff', pitchTex)); pitch.rotation.x = -Math.PI / 2; pitch.position.set(0, -1.4, 0); atoms.add(pitch);
  const electrons: { m: THREE.Object3D; cx: number; r: number; tilt: number; sp: number; ph: number }[] = [];
  const mkAtom = (cx: number, cloud: string, body: string) => {
    const g = new THREE.Group(); g.position.x = cx;
    for (const [x, y, z] of [[0, 0, 0], [0.08, 0.05, 0.04], [-0.07, 0.04, -0.05], [0.03, -0.08, 0.04], [-0.04, -0.05, 0.07]]) { const s = ball(0.07, body, [x, y, z]); g.add(s); }
    const shell = new THREE.Mesh(new THREE.SphereGeometry(2.6, 28, 20), new THREE.MeshBasicMaterial({ color: cloud, transparent: true, opacity: 0.17, depthWrite: false, fog: false }));
    g.add(shell);
    for (let i = 0; i < 3; i++) { const e = ball(0.11, '#ffe27a', [0, 0, 0]); g.add(e); electrons.push({ m: e, cx: 0, r: 1.6 + i * 0.4, tilt: i * 1.0, sp: 0.045 - i * 0.008, ph: i * 2.1 + cx }); }
    atoms.add(g); return g;
  };
  mkAtom(-2.8, '#ff8a7a', '#e0555a'); mkAtom(2.8, '#e0a050', '#8a5aa8');
  // Wire elektron berputar dipasang ke grup atom masing-masing (posisi relatif)
  const eParents = electrons.map(e => e.m.parent!);

  return {
    root,
    anim(f: number) {
      const m = nightMix(f);
      electrons.forEach((e, i) => { const a = f * e.sp + e.ph; e.m.position.set(Math.cos(a) * e.r, Math.sin(a) * e.r * Math.sin(e.tilt + 0.5), Math.sin(a) * e.r * Math.cos(e.tilt + 0.5)); void eParents[i]; });
      const gap = magnetGap(f), night = f >= PIVOT_F;
      magL.visible = magR.visible = beam.visible = night;
      magL.position.x = -(gap / 2 + 0.16); magR.position.x = gap / 2 + 0.16;
      beam.scale.x = gap; beam.visible = night && f >= 1650;
      (pane.material as THREE.MeshBasicMaterial).color.set('#cfe6ff').lerp(new THREE.Color('#16256b'), m);
    },
  };
}
