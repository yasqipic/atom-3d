// Root.tsx — daftarkan komposisi (atau salin <Composition> ini ke Root.tsx proyek Anda, di samping BridgeShort).
import React from 'react';
import { Composition } from 'remotion';
import { AtomShort, ATOM_META } from './Bridge';

export const RemotionRoot: React.FC = () => (
  <Composition id={ATOM_META.id} component={AtomShort} width={ATOM_META.width} height={ATOM_META.height} fps={ATOM_META.fps} durationInFrames={ATOM_META.durationInFrames} />
);
